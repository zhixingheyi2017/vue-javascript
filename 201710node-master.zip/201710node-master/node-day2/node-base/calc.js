// 写一个求和方法
/*function sum(...args) {
    return args.reduce((prev,next)=>prev+next);
}*/
let sum = (...args)=>args.reduce((prev,next)=>prev+next);
console.log(1);
//module.exports = sum;
//exports.b = sum;
//module.exports.b = sum;
//global.sum = sum;