<template>
  <div>
    <Counter></Counter>
  </div>
</template>
<script>
import Counter from './components/Counter.vue'
export default {
    data(){
        return {msg: 'hello'}
    },
    created(){
    },
    methods: {},
    computed: {},
    components: {Counter}
}
</script>
<style scoped>

</style>
