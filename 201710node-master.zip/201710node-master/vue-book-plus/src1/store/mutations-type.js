// 增加
export const INCREMENT ='INCREMENT';

// 减少
export const DECREMENT = 'DECREMENT';

