
let a = 1;
export default {
    a:1
}

