let str = '我很帅';
module.exports = str;