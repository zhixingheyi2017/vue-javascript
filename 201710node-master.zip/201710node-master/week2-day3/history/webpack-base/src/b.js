let str = '我非常帅';
export default str