<template>
  <div><h1><span>hello</span></h1></div>
</template>
<script>
    export default {
        data(){
            return {}
        },
        methods: {},
        computed: {},
        components: {}
    }
</script>
<style scoped></style>